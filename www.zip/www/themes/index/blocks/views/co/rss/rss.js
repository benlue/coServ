ctrl.startup = function()  {
    console.log('showing RSS list.');
};
