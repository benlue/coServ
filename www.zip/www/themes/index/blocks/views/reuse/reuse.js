ctrl.startup = function() {};
